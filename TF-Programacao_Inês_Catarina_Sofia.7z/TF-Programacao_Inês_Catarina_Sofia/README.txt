Trabalho Final - Jogo do Monstro em Pygame
In�s Martins Barradas - a21803669
Catarina Matias - a21801693
Ana Sofia Carvalho - a21802128
UC Fundamentos de Programa��o - Janeiro de 2019

>> Regras:
	- Escapa aos zombies!!!
	- Usa as teclas das setas (cima e baixo) para controlar a dire��o para andar, e (esquerda, direita) para te virares para os teus inimigos!
	- Usa a tecla Espa�o para disparar e te defenderes contra os zombies.
	
	Se morreres, ter�s de voltar ao in�cio!