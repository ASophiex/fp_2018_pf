
# Trabalho Final - Jogo do Monstro em Pygame
# Ana Carvalho - a21802128
# Ctarina Matias - a 21801693
# Inês Martins Barradas - a21803669
# UC Fundamentos de Programação - Janeiro de 2019

import pygame, math
from time import sleep
pygame.init()

win = pygame.display.set_mode((1500, 700))

pygame.display.set_caption("Jogo do Monstro")

screenWidth = 1500

font = pygame.font.SysFont('comicsans', 40, True)
font2 = pygame.font.SysFont('comicsans', 60, True)

walkRight = [pygame.image.load('sprites/Image17.png'), pygame.image.load('sprites/Image18.png')]
walkLeft = [pygame.image.load('sprites/Image17,1.png'), pygame.image.load('sprites/Image18,1.png')]
walkUp = [pygame.image.load('sprites/Image17.png'), pygame.image.load('sprites/Image18.png')]
walkDown = [pygame.image.load('sprites/Image17.png'), pygame.image.load('sprites/Image18.png')]
bg = pygame.image.load('sprites/topwall.png').convert_alpha()
char = pygame.image.load('sprites/_idle.png')
itens = [pygame.image.load('sprites/ouro.png'), pygame.image.load('sprites/hole.png')]

clock = pygame.time.Clock()

music = pygame.mixer.music.load('sound/111.mp3')
pygame.mixer.music.play(-1)

score = 0
timer = 30
timerCut = 0


class hole(object):

    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (self.x, self.y +30, 128, 80)
    #draw poço
    def draw(self, win):
        win.blit(itens[1], (self.x, self.y))
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

class player(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.vel = 10
        self.left = False
        self.right = False
        self.up = False
        self.down = False
        self.walkCount = 0
        self.standing = True
        self.hitbox = (self.x, self.y, 100, 170)

    def draw(self, win):
        if  self.walkCount + 1 >= 6:
            self.walkCount = 0

        if not(self.standing):
            if self.left:
                win.blit(walkLeft[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            elif self.right:
                win.blit(walkRight[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            elif self.up:
                win.blit(walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            elif self.down:
                win.blit(walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
        #Para manter as balas na posição correcta
        else:
            if self.right:
                win.blit(walkRight[0], (self.x, self.y))
            elif self.left:
                win.blit(walkLeft[0], (self.x, self.y))
            elif self.up:
                win.blit(walkUp[0], (self.x, self.y))
            else:
                win.blit(walkDown[0], (self.x, self.y))
        self.hitbox = (self.x, self.y, 100, 170)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit(self):
        self.x = 300
        self.y = 0
        self.walkCount= 0
        font1 = pygame.font.SysFont('comicsans', 100)
        text = font1.render('-100', 1, (255, 0, 0))
        win.blit(text, (250 - (text.get_width()/2), 200))
        pygame.display.update()
        i = 0
        while i < 100:
            pygame.time.delay(10)
            i += 1
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    i = 101
                    pygame.quit()

#Classe para as balas que a personagem dispara
class projectile(object):
    def __init__(self, x, y, radius, color, facing):
        self. x = x
        self.y = y
        self.radius = radius
        self.color = color
        self.facing = facing
        self.vel = 12 * facing

    #Desenhar as balas
    def draw(self, win):
        pygame.draw.circle(win, self.color, (self.x, self.y), self.radius)


class enemy(object):
    walkUp = [pygame.image.load('sprites/Image42.png'), pygame.image.load('sprites/Image43.png')]
    walkDown = [pygame.image.load('sprites/Image42,1.png'), pygame.image.load('sprites/Image43,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 10
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True
    #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount //3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21),(self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit(self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False

class enemy2(object):
    walkUp = [pygame.image.load('sprites/Image42.png'), pygame.image.load('sprites/Image43.png')]
    walkDown = [pygame.image.load('sprites/Image42,1.png'), pygame.image.load('sprites/Image43,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 9
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True

        #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21),(self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit (self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False

class enemy3(object):
    walkUp = [pygame.image.load('sprites/Image101.png'), pygame.image.load('sprites/Image100.png')]
    walkDown = [pygame.image.load('sprites/Image101,1.png'), pygame.image.load('sprites/Image100,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 11
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True

        #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21),(self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit (self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False

class enemy4(object):
    walkUp = [pygame.image.load('sprites/Image101.png'), pygame.image.load('sprites/Image100.png')]
    walkDown = [pygame.image.load('sprites/Image101,1.png'), pygame.image.load('sprites/Image100,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 9
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True

        #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21), (self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit (self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            
class enemy5(object):
    walkUp = [pygame.image.load('sprites/Image101.png'), pygame.image.load('sprites/Image100.png')]
    walkDown = [pygame.image.load('sprites/Image101,1.png'), pygame.image.load('sprites/Image100,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 9
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True

        #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21), (self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit (self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False

class enemy6(object):
    walkUp = [pygame.image.load('sprites/Image42.png'), pygame.image.load('sprites/Image43.png')]
    walkDown = [pygame.image.load('sprites/Image42,1.png'), pygame.image.load('sprites/Image43,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 10
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True

        #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21),(self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit (self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False
            
class enemy7(object):
    walkUp = [pygame.image.load('sprites/Image42.png'), pygame.image.load('sprites/Image43.png')]
    walkDown = [pygame.image.load('sprites/Image42,1.png'), pygame.image.load('sprites/Image43,1.png')]

    def __init__(self, x, y, width, height, end):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.end = end
        self.path = [self.y, self.end]
        self.walkCount = 0
        self.vel = 10
        self.hitbox = (self.x, self.y, 100, 90)
        self.health = 10
        self.visible = True

        #inimigo
    def draw(self, win):
        self.move()
        if self.visible:
            if self.walkCount + 1 >= 6:
                self.walkCount = 0

            if self.vel > 0:
                win.blit(self.walkUp[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1
            else:
                win.blit(self.walkDown[self.walkCount // 3], (self.x, self.y))
                self.walkCount += 1

            pygame.draw.rect(win, (160, 0, 0), (self.hitbox[0], self.hitbox[1] - 20, 80, 10))
            pygame.draw.rect(win, (21, 91, 21),(self.hitbox[0], self.hitbox[1] - 20, 80 - (5 * (10 - self.health)), 10))

    #mover o inimigo
    def move(self):
        if self.vel > 0:
            if self.y + self.vel < self.path[1]:
                self.y += self.vel
            else:
                self.vel = self.vel * -1
                self.walkCount = 0
        else:
            if self.y - self.vel > self.path[0]:
                self.y += self.vel
            else:
                self.vel = self.vel * - 1
                self.walkCount = 0
        self.hitbox = (self.x, self.y, 100, 90)
        #pygame.draw.rect(win, (255, 0, 0), self.hitbox, 2)

    def hit (self):
        if self.health > 0:
            self.health -= 1
        else:
            self.visible = False

class tesouroClass(object):
    def __init__(self, x, y, width, height):
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        self.hitbox = (self.x + 20, self.y + 20, 20, 20)
        self.visivel = True

    def draw(self,win):
        if self.visivel:
            win.blit(itens[0], (self.x, self.y))


#Timer - O jogador tem x segundos para apanhar o ouro, ou perde.
#Parte impressa em ecrã
timerPrint = font.render('Timer: ' + str(timerCut), 1, (255, 255, 255))
boxsize = timerPrint.get_rect()
timerPosiX = (screenWidth-boxsize[2])/2


#sucumbos é o nome da personagem principal
def redrawGameWindow():
    win.blit(bg, (0, 0))
    text = font.render('Score: ' + str(score), 1, (255, 255, 255))
    timerPrint = font.render('Timer: ' + str(timerCut), 1, (255, 255, 255))
    win.blit(text, (10, 10))
    win.blit(timerPrint, (timerPosiX, 50))
    Hole1.draw(win)
    Hole2.draw(win)
    Hole3.draw(win)
    Hole4.draw(win)
    sucumbos.draw(win)
    inves.draw(win)
    inves2.draw(win)
    inves3.draw(win)
    fenix.draw(win)
    fenix2.draw(win)
    fenix3.draw(win)
    fenix4.draw(win)
    ouro.draw(win)
    for bullet in bullets:
        bullet.draw(win)

    pygame.display.update()

#mainloop
font = pygame.font.SysFont('comicsans', 40, True) #existem duas "font". A outra está no inicio, abaixo de ScreenWidth
Hole1 = hole(200, 100, 128, 128)
Hole2 = hole(900, 300, 128, 128)
Hole3 = hole(400, 450, 128, 128)
Hole4 = hole(1200, 90, 128, 128)
sucumbos = player(1400, 550, 152, 170)
inves = enemy(500, 50, 102, 60, 600)
inves2 = enemy2(300, 150, 102, 60, 500)
inves3 = enemy6(100, 97, 102, 60, 500)
fenix = enemy3(700, 120, 102, 70, 600)
fenix2 = enemy4(400, 60, 102, 70, 500)
fenix3 = enemy5(800, 83, 102, 70, 500)
fenix4 = enemy7(1000, 64, 102, 70, 500)
ouro = tesouroClass(45, 45, 64, 64)
shootLoop = 0
bullets = []
run = True
while run:
    clock.tick(30)

    if inves.visible == True:
        if sucumbos.hitbox[1] < inves.hitbox[1] + inves.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > inves.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > inves.hitbox[0] and sucumbos.hitbox[0] < inves.hitbox[0] + inves.hitbox[2]:
                sucumbos.hit()
                score -= 100
    if inves2.visible == True:
        if sucumbos.hitbox[1] < inves2.hitbox[1] + inves2.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > inves2.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > inves2.hitbox[0] and sucumbos.hitbox[0] < inves2.hitbox[0] + inves2.hitbox[2]:
                sucumbos.hit()
                score -= 100
    if inves3.visible == True:
        if sucumbos.hitbox[1] < inves3.hitbox[1] + inves3.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > inves3.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > inves3.hitbox[0] and sucumbos.hitbox[0] < inves3.hitbox[0] + inves3.hitbox[2]:
                sucumbos.hit()
                score -= 100
    if fenix.visible == True:
        if sucumbos.hitbox[1] < fenix.hitbox[1] + fenix.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > fenix.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > fenix.hitbox[0] and sucumbos.hitbox[0] < fenix.hitbox[0] + fenix.hitbox[2]:
                sucumbos.hit()
                score -= 100
    if fenix2.visible == True:
        if sucumbos.hitbox[1] < fenix2.hitbox[1] + fenix2.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > fenix2.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > fenix2.hitbox[0] and sucumbos.hitbox[0] < fenix2.hitbox[0] + fenix2.hitbox[2]:
                sucumbos.hit()
                score -= 100
    if fenix3.visible == True:
        if sucumbos.hitbox[1] < fenix3.hitbox[1] + fenix3.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > fenix3.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > fenix3.hitbox[0] and sucumbos.hitbox[0] < fenix3.hitbox[0] + fenix3.hitbox[2]:
                sucumbos.hit()
                score -= 100
    if fenix4.visible == True:
        if sucumbos.hitbox[1] < fenix4.hitbox[1] + fenix4.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > fenix4.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > fenix4.hitbox[0] and sucumbos.hitbox[0] < fenix4.hitbox[0] + fenix4.hitbox[2]:
                sucumbos.hit()
                score -= 100

    #ouro
    if ouro.visivel == True:
        if sucumbos.hitbox[1] < ouro.hitbox[1] + ouro.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > ouro.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > ouro.hitbox[0] and sucumbos.hitbox[0] < ouro.hitbox[1] + ouro.hitbox[2]:
                ouro.visivel = False
                pygame.draw.rect(win, (0, 0, 0), (00, 4, 500, 100))
                text = font.render('Ouro obtido. Ganhas-te o jogo.', 1, (255, 255, 255))
                win.blit(text, (00, 30))
                pygame.display.update()
                sleep(3)
                run = False


    if shootLoop > 0:
        shootLoop += 1
    if shootLoop > 3:
        shootLoop = 0

    for event in pygame.event.get():
        if event.type ==pygame.QUIT:
            run = False

    for bullet in bullets:
        if inves.visible == True:
            if bullet.y - bullet.radius < inves.hitbox[1] + inves.hitbox[3] and bullet.y + bullet.radius > inves.hitbox[1]:
                if bullet.x + bullet.radius > inves.hitbox[0] and bullet.x - bullet.radius < inves.hitbox[0] + inves.hitbox[2]:
                    inves.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))
                    
        if inves2.visible == True:
            if bullet.y - bullet.radius < inves2.hitbox[1] + inves2.hitbox[3] and bullet.y + bullet.radius > inves2.hitbox[1]:
                if bullet.x + bullet.radius > inves2.hitbox[0] and bullet.x - bullet.radius < inves2.hitbox[0] + inves2.hitbox[2]:
                    inves2.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))
                    
        if inves3.visible == True:
            if bullet.y - bullet.radius < inves3.hitbox[1] + inves3.hitbox[3] and bullet.y + bullet.radius > inves3.hitbox[1]:
                if bullet.x + bullet.radius > inves3.hitbox[0] and bullet.x - bullet.radius < inves3.hitbox[0] + inves3.hitbox[2]:
                    inves3.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))
                    
        if fenix.visible == True:
            if bullet.y - bullet.radius < fenix.hitbox[1] + fenix.hitbox[3] and bullet.y + bullet.radius > fenix.hitbox[1]:
                if bullet.x + bullet.radius > fenix.hitbox[0] and bullet.x - bullet.radius < fenix.hitbox[0] + fenix.hitbox[2]:
                    fenix.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))
                    
        if fenix2.visible == True:
            if bullet.y - bullet.radius < fenix2.hitbox[1] + fenix2.hitbox[3] and bullet.y + bullet.radius > fenix2.hitbox[1]:
                if bullet.x + bullet.radius > fenix2.hitbox[0] and bullet.x - bullet.radius < fenix2.hitbox[0] + fenix2.hitbox[2]:
                    fenix2.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))
                    
        if fenix3.visible == True:
            if bullet.y - bullet.radius < fenix3.hitbox[1] + fenix3.hitbox[3] and bullet.y + bullet.radius > fenix3.hitbox[1]:
                if bullet.x + bullet.radius > fenix3.hitbox[0] and bullet.x - bullet.radius < fenix3.hitbox[0] + fenix3.hitbox[2]:
                    fenix3.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))
                    
        if fenix4.visible == True:
            if bullet.y - bullet.radius < fenix4.hitbox[1] + fenix4.hitbox[3] and bullet.y + bullet.radius > fenix4.hitbox[1]:
                if bullet.x + bullet.radius > fenix4.hitbox[0] and bullet.x - bullet.radius < fenix4.hitbox[0] + fenix4.hitbox[2]:
                    fenix4.hit()
                    score += 1
                    bullets.pop(bullets.index(bullet))

        #se cair num poço
        if sucumbos.hitbox[1] < Hole1.hitbox[1] + Hole1.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > Hole1.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > Hole1.hitbox[0] and sucumbos.hitbox[0] < Hole1.hitbox[0] + Hole1.hitbox[2]:
                textFin = font2.render('Caiste num poço!', 1, (255, 255, 255))
                win.blit(textFin, (550, 150))
                ScoreFin = font2.render('Score: ' + str(score), 1, (255, 255, 255))
                win.blit(ScoreFin, (650, 250))
                pygame.display.update()
                pygame.time.wait (400)
                run = False
        if sucumbos.hitbox[1] < Hole2.hitbox[1] + Hole2.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > Hole2.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > Hole2.hitbox[0] and sucumbos.hitbox[0] < Hole2.hitbox[0] + Hole2.hitbox[2]:
                textFin = font2.render('Caiste num poço!', 1, (255, 255, 255))
                win.blit(textFin, (550, 150))
                ScoreFin = font2.render('Score: ' + str(score), 1, (255, 255, 255))
                win.blit(ScoreFin, (650, 250))
                pygame.display.update()
                pygame.time.wait (400)
                run = False
        if sucumbos.hitbox[1] < Hole3.hitbox[1] + Hole3.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > Hole3.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > Hole3.hitbox[0] and sucumbos.hitbox[0] < Hole3.hitbox[0] + Hole3.hitbox[2]:
                textFin = font2.render('Caiste num poço!', 1, (255, 255, 255))
                win.blit(textFin, (550, 150))
                ScoreFin = font2.render('Score: ' + str(score), 1, (255, 255, 255))
                win.blit(ScoreFin, (650, 250))
                pygame.display.update()
                pygame.time.wait (400)
                run = False
        if sucumbos.hitbox[1] < Hole4.hitbox[1] + Hole4.hitbox[3] and sucumbos.hitbox[1] + sucumbos.hitbox[3] > Hole4.hitbox[1]:
            if sucumbos.hitbox[0] + sucumbos.hitbox[2] > Hole4.hitbox[0] and sucumbos.hitbox[0] < Hole4.hitbox[0] + Hole4.hitbox[2]:
                textFin = font2.render('Caiste num poço!', 1, (255, 255, 255))
                win.blit(textFin, (550, 150))
                ScoreFin = font2.render('Score: ' + str(score), 1, (255, 255, 255))
                win.blit(ScoreFin, (650, 250))
                pygame.display.update()
                pygame.time.wait (400)
                run = False


        if bullet.x < 1500 and bullet.x > 0:
            bullet.x += bullet.vel
        else: #Apagar as balas para n ficarem a flutuar no canto do ecrã
            bullets.pop(bullets.index(bullet))

    keys = pygame.key.get_pressed()

    if keys [pygame.K_SPACE] and shootLoop == 0:
        if sucumbos.left:
            facing = -1
        elif sucumbos.right:
            facing = 1
        elif sucumbos.up:
            facing = 1
        else:
            facing = -1
        if len(bullets) < 10000:  #Número de balas para aparecem no ecrã de uam vez
            bullets.append(projectile(round(sucumbos.x + sucumbos.width //2), round(sucumbos.y + sucumbos.height //2), 6, (0, 0, 0), facing)) #Para as balas sairem do meio da personagem

        shootLoop = 1
        
    if keys [pygame.K_c]:
        sucumbos.vel = 25
    else:
        sucumbos.vel = 10

    if keys[pygame.K_LEFT] and sucumbos.x > sucumbos.vel:
        sucumbos.x -= sucumbos.vel
        sucumbos.left = True
        sucumbos.rigth = False
        sucumbos.standing = False
    elif keys [pygame.K_RIGHT] and sucumbos.x < 1500 - sucumbos.width - sucumbos.vel:
        sucumbos.x += sucumbos.vel
        sucumbos.right = True
        sucumbos.left = False
        sucumbos.standing = False
    elif keys [pygame.K_UP] and sucumbos.y > sucumbos.vel:
        sucumbos.y -= sucumbos.vel
        sucumbos.up = True
        sucumbos.down = False
        sucumbos.standing = False
    elif keys [pygame.K_DOWN] and sucumbos.y < 700 - sucumbos.height - sucumbos.vel:
        sucumbos.y += sucumbos.vel
        sucumbos.down = True
        sucumbos.up = False
        sucumbos.standing = False
    else:
        sucumbos.standing = True
        sucumbos.walkCount = 0

    if timer <= 0:
        #win.fill(0,0,0)
        textFin = font2.render('O Tempo Acabou', 1, (255, 255, 255))
        win.blit(textFin, (550, 150))
        ScoreFin = font2.render('Score: ' + str(score), 1, (255, 255, 255))
        win.blit(ScoreFin, (650, 250))
        pygame.display.update()
        pygame.time.wait (1000)
        run = False

    
    redrawGameWindow()

    #Incrementa o tempo para o timer
    seconds = clock.tick()/1000.0
    timer -= seconds
    timerCut = math.trunc(timer)

pygame.quit()
