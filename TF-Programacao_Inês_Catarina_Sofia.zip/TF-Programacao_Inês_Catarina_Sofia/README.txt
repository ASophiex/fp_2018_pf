Trabalho Final - Jogo do Monstro em Pygame
In�s Martins Barradas - a21803669
Catarina Matias - a21801693
Ana Sofia Carvalho - a21802128
UC Fundamentos de Programa��o - Janeiro de 2019

>> Regras:
	- Encontra o ouro para escapar � masmorra!
	- Ter�s de derrotar as criaturas que a habitam e evitar po�os no ch�o.
	- Usa as teclas das setas (cima, baixo, esquerda, direita) para te movimentares.
	- Usa o Espa�o para disparar balas nos teus inimigos, e a tecla "C" para correr mais r�pido!
	- Mas CUIDADO! S� tens 30 segundos para agarrar o ouro e escapar!